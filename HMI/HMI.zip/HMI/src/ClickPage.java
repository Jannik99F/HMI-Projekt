import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Random;

public class ClickPage {
    JFrame frame = new JFrame();
    JLabel scoreLabel = new JLabel();
    static JButton left = new JButton();

    static JButton left2 = new JButton();
    static JButton right = new JButton();

    static JButton right2 = new JButton();
    static int score = 0;
    ClickPage(){
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920,1080);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.getContentPane().setBackground(Color.WHITE);
        frame.setLayout(null);
        frame.setVisible(true);


        scoreLabel.setBounds(940, 440,400,100);
        scoreLabel.setText(""+score);
        scoreLabel.setFont(new Font("Dialog",0,100));
        frame.add(scoreLabel);

        left.addActionListener(this::actionPerformed);
        left.setBounds(10, 960,945,50);
        left.setBackground(Color.GREEN);
        left.setFocusable(false);
        frame.add(left);

        left2.addActionListener(this::actionPerformed);
        left2.setBounds(10, 900,945,50);
        left2.setBackground(Color.RED);
        left2.setFocusable(false);
        frame.add(left2);

        right.addActionListener(this::actionPerformed);
        right.setBounds(970, 960,945,50);
        right.setBackground(Color.RED);
        right.setFocusable(false);
        frame.add(right);

        right2.addActionListener(this::actionPerformed);
        right2.setBounds(970, 900,945,50);
        right2.setBackground(Color.RED);
        right2.setFocusable(false);
        frame.add(right2);

        changeColor();
        System.out.println("Pause");
    }
    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignored) {
        }
    }
    //@Override
    public void actionPerformed(ActionEvent e) {
        //todo if button get clicked
        if (e.getSource() == left){
            if(left.getBackground() == Color.GREEN){
                score+= 1;
            }else score -=1;
        }else if (e.getSource() == right){
            if(right.getBackground() == Color.GREEN){
                score+= 1;
            }else score -=1;
        }else if (e.getSource() == left2){
            if(left2.getBackground() == Color.GREEN){
                score+= 1;
            }else score -=1;
        }else if (e.getSource() == right2){
            if(right2.getBackground() == Color.GREEN){
                score+= 1;
            }else score -=1;
        }
        scoreLabel.setText(""+score);
    }

    public static int getRandomNumber(){
        Random random = new Random();
        int randomNumber = random.nextInt(10);
        return randomNumber;
    }

    public static void changeColor() {
        while(true){
            sleep(getRandomNumber() * 1000);
            if (left.getBackground() == Color.GREEN){
                left.setBackground(Color.RED);
                right.setBackground(Color.GREEN);
                System.out.println("Change");
            }else if (left.getBackground() == Color.RED) {
                left.setBackground(Color.GREEN);
                right.setBackground(Color.RED);
            }
            if (score == 20){
                break;
            }
        }
    }
}
